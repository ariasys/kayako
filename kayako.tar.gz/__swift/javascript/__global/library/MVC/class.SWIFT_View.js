SWIFT.Library.View = Backbone.View.extend({
});