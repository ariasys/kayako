<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author		Varun Shoor
 *
 * @package		SWIFT
 * @copyright	Copyright (c) 2001-2012, Kayako
 * @license		http://www.kayako.com/license
 * @link		http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The Dwoo Template File Abstraction Layer
 * 
 * @author Varun Shoor
 */
class SWIFT_TemplateEngineFile extends Dwoo_Template_File
{
	/**
	 * Constructor
	 *
	 * @param string $file the path to the template file, make sure it exists
	 */
	public function __construct($_fileName, $_cacheTime = null, $_cacheId = null, $_compileId = null, $_includePath = null)
	{
		parent::__construct($_fileName, 0, 0, md5($_fileName), $_cacheTime, $_cacheId, $_compileId, $_includePath);

		return true;
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{

		return true;
	}

	/**
	 * returns the full compiled file name and assigns a default value to it if
	 * required
	 *
	 * @param Dwoo $dwoo the dwoo instance that requests the file name
	 * @return string the full path to the compiled file
	 */
	protected function getCompiledFilename(Dwoo $dwoo)
	{
		$_compiledFilename = parent::getCompiledFilename($dwoo);
		
		$_finalCompiledFilename = md5($_compiledFilename . SWIFT::Get('InstallationHash')) .'.php';

		return './'. SWIFT_BASEDIRECTORY .'/'. SWIFT_CACHEDIRECTORY . '/' . $_finalCompiledFilename;
	}
}
?>