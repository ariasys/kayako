<?php
/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author         Varun Shoor
 *
 * @package        SWIFT
 * @copyright      Copyright (c) 2001-2012, Kayako
 * @license        http://www.kayako.com/license
 * @link           http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The Akismet Checking Library
 *
 * @author Varun Shoor
 */
class SWIFT_Akismet extends SWIFT_Library
{
	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	public function __construct()
	{
		parent::__construct();

		if ($this->Settings->Get('security_enableakismet') == '0' || $this->Settings->Get('security_akismetkey') == '') {
			throw new SWIFT_Exception(SWIFT_INVALIDDATA);
		}

		return true;
	}

	/**
	 * Check against Akismet DB
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_fullName The User Full Name
	 * @param string $_email    The Email Address
	 * @param string $_contents The Comment Contents
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Check($_fullName, $_email, $_contents)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
		}

		$_variableContainer = array(
			'blog'         => SWIFT::Get('swiftpath'), 'user_ip' => SWIFT::Get('IP'), 'user_agent' => $_SERVER['HTTP_USER_AGENT'], 'referrer' => $_SERVER['HTTP_REFERER'],
			'comment_type' => 'comment', 'comment_author' => $_fullName, 'comment_author_email' => $_email, 'comment_content' => $_contents
		);

		$_verifyResult = self::DispatchPost($this->Settings->Get('security_akismetkey') . '.rest.akismet.com', 80, '/1.1/comment-check', $_variableContainer);

		if ($_verifyResult == 'true') {
			return false;
		}

		return true;
	}

	/**
	 * Mark as Spam in Akismet DB
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_fullName  The User Full Name
	 * @param string $_email     The Email Address
	 * @param string $_contents  The Comment Contents
	 * @param string $_userAgent The User Agent
	 * @param string $_referrer  The Referrer
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function MarkAsSpam($_fullName, $_email, $_contents, $_userAgent, $_referrer)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
		}

		$_variableContainer = array(
			'blog'         => SWIFT::Get('swiftpath'), 'user_ip' => SWIFT::Get('IP'), 'user_agent' => $_userAgent, 'referrer' => $_referrer,
			'comment_type' => 'comment', 'comment_author' => $_fullName, 'comment_author_email' => $_email, 'comment_content' => $_contents
		);

		$_verifyResult = self::DispatchPost($this->Settings->Get('security_akismetkey') . '.rest.akismet.com', 80, '/1.1/submit-spam', $_variableContainer);

		if ($_verifyResult == 'true') {
			return false;
		}

		return true;
	}

	/**
	 * Mark as Not Spam in Akismet DB
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_fullName  The User Full Name
	 * @param string $_email     The Email Address
	 * @param string $_contents  The Comment Contents
	 * @param string $_userAgent The User Agent
	 * @param string $_referrer  The Referrer
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function MarkAsHam($_fullName, $_email, $_contents, $_userAgent, $_referrer)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
		}

		$_variableContainer = array(
			'blog'         => SWIFT::Get('swiftpath'), 'user_ip' => SWIFT::Get('IP'), 'user_agent' => $_userAgent, 'referrer' => $_referrer,
			'comment_type' => 'comment', 'comment_author' => $_fullName, 'comment_author_email' => $_email, 'comment_content' => $_contents
		);

		$_verifyResult = self::DispatchPost($this->Settings->Get('security_akismetkey') . '.rest.akismet.com', 80, '/1.1/submit-ham', $_variableContainer);

		if ($_verifyResult == 'true') {
			return false;
		}

		return true;
	}

	/**
	 * Call up a HTTP Post
	 *
	 * DispatchPost("www.fat.com", 80, "/weightloss.pl", array("name" => "obese bob", "age" => "20"));
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_server    The Server
	 * @param string $_port      The Port
	 * @param string $_url       The URL to Execute
	 * @param array  $_variables The Variables
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static protected function DispatchPost($_server, $_port, $_url, $_variables)
	{
		$_userAgent = SWIFT_PRODUCT . '/' . SWIFT_VERSION . ' | Akismet/1.11';

		$_urlEncoded = "";
		while (list($_key, $_value) = each($_variables)) {
			$_urlEncoded .= urlencode($_key) . "=" . urlencode($_value) . "&";
		}

		$_urlEncoded = mb_substr($_urlEncoded, 0, -1);

		$_contentLength = mb_strlen($_urlEncoded);

		$_headers = "POST " . $_url . " HTTP/1.1\nAccept: */*
Accept-Language: en-us
Content-Type: application/x-www-form-urlencoded
User-Agent: " . $_userAgent . "
Host: " . $_server . "
Connection: Keep-Alive
Cache-Control: no-cache
Content-Length: " . $_contentLength . "

";

		$_errorNumber = 0;
		$_errorString = '';
		$_fp          = fsockopen($_server, $_port, $_errorNumber, $_errorString, 3);
		if (!$_fp) {
			return false;
		}

		fputs($_fp, $_headers);
		fputs($_fp, $_urlEncoded);

		$_result = '';
		while (!feof($_fp)) {
			$_result .= fgets($_fp, 1024);
		}

		fclose($_fp);

		$_result = explode("\r\n\r\n", $_result, 2);

		return trim($_result[1]);
	}
}
