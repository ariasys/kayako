<?php

/**
 * ###############################################
 *
 * SWIFT Framework
 * _______________________________________________
 *
 * @author         Varun Shoor
 *
 * @package        SWIFT
 * @copyright      Copyright (c) 2001-2012, Kayako
 * @license        http://www.kayako.com/license
 * @link           http://www.kayako.com
 *
 * ###############################################
 */

/**
 * The Core Model Management Class
 *
 * @author Varun Shoor
 */
class SWIFT_Model extends SWIFT_Base implements SWIFT_Model_Interface
{
	protected $_updatePool = array();
	protected $_dataStore = array();
	static protected $_updatePoolQueue = array();

	/**
	 * Constructor
	 *
	 * @author Varun Shoor
	 *
	 * @param SWIFT_Data|string|array $_SWIFT_DataObject (OPTIONAL) This has been kept optional for backward compatibility
	 *
	 * @throws SWIFT_Exception If the Model could not be Initialized
	 */
	public function __construct($_SWIFT_DataObject = null)
	{
		if (!$_SWIFT_DataObject instanceof SWIFT_Data && is_numeric($_SWIFT_DataObject)) {
			$_SWIFT_DataObject = new SWIFT_DataID($_SWIFT_DataObject);
		} else if (!$_SWIFT_DataObject instanceof SWIFT_Data && _is_array($_SWIFT_DataObject)) {
			$_SWIFT_DataObject = new SWIFT_DataStore($_SWIFT_DataObject);
		}

		if (!$this->Initialize()) {
			throw new SWIFT_Exception(SWIFT_CLASSNOTLOADED);
		} else if ($_SWIFT_DataObject instanceof SWIFT_Data && $_SWIFT_DataObject->GetIsClassLoaded()) {
			if (!$this->LoadData($_SWIFT_DataObject)) {
				throw new SWIFT_Exception('Failed to load ' . __CLASS__ . ' Object');
			}
		}

		parent::__construct();
	}

	/**
	 * Destructor
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function __destruct()
	{
		$this->ProcessUpdatePool();

		parent::__destruct();

		return true;
	}

	/**
	 * Retrieve the identifier for this model
	 *
	 * @author Varun Shoor
	 *
	 * @param $_id
	 *
	 * @return SWIFT_Model
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	static public function GetOnID($_id)
	{
		return new self(new SWIFT_DataID($_id));
	}

	/**
	 * Retrieve the identifier for this model
	 *
	 * @author Varun Shoor
	 * @return int
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetID()
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		}

		if (static::PRIMARY_KEY) {
			return $this->GetProperty($this->GetPrimaryKeyName());
		}

		return 0;
	}

	/**
	 * Retrieve the Table Name
	 *
	 * @author Varun Shoor
	 * @return string The Table Name
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	static public function GetTableName()
	{
		if (static::TABLE_NAME) {
			return static::TABLE_NAME;
		}

		return false;
	}

	/**
	 * Retrieve the Primary Key Name
	 *
	 * @author Varun Shoor
	 * @return string The Primary Key Name
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	static public function GetPrimaryKeyName()
	{
		if (static::PRIMARY_KEY) {
			return static::PRIMARY_KEY;
		}

		return false;
	}

	/**
	 * Processes the Update Pool Data
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function ProcessUpdatePool()
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		} else if (!_is_array($this->GetUpdatePool()) || self::GetTableName() === false || self::GetPrimaryKeyName() === false) {
			return false;
		}

		$this->Database->AutoExecute(TABLE_PREFIX . self::GetTableName(), $this->GetUpdatePool(), 'UPDATE', self::GetPrimaryKeyName() . " = '" . intval($this->GetProperty(self::GetPrimaryKeyName())) . "'");

		$this->ClearUpdatePool();

		return true;
	}

	/**
	 * Call a custom function
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_functionName
	 * @param array  $_argumentContainer
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function __call($_functionName, $_argumentContainer)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		}

		$_baseFunctionName = mb_strtolower($_functionName);

		// Get{PROPERTY}
		if (strtolower(substr($_baseFunctionName, 0, strlen('get')) == 'get')) {
			$_propertyName = mb_strtolower(trim(substr($_baseFunctionName, 3)));
			if (!isset($this->_dataStore[$_propertyName])) {
				throw new SWIFT_Exception($_functionName . ' failed, property "' . $_propertyName . '" not found in datastore.');
			}

			return $this->GetProperty($_propertyName);
			// Set{PROPERTY}
		} else if (strtolower(substr($_baseFunctionName, 0, strlen('set')) == 'set')) {
			$_propertyName = mb_strtolower(trim(substr($_baseFunctionName, 3)));
			if (!isset($this->_dataStore[$_propertyName])) {
				throw new SWIFT_Exception($_functionName . ' failed, property "' . $_propertyName . '" not found in datastore.');
			} else if (!isset($_argumentContainer[0])) {
				throw new SWIFT_Exception($_functionName . ' failed, no value specified.');
			}

			$this->SetProperty($_propertyName, $_argumentContainer[0]);

			return true;
		}

		return true;
	}

	/**
	 * Retrieve a datastore property
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_propertyName
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function __get($_propertyName)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		} else if (!isset($this->_dataStore[$_propertyName])) {
			throw new SWIFT_Exception('Property retrieval failed, "' . $_propertyName . '" not found in datastore.');
		}

		return $this->GetProperty($_propertyName);
	}

	/**
	 * Check to see if the property is set
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_propertyName
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function __isset($_propertyName)
	{
		return isset($this->_dataStore[$_propertyName]);
	}

	/**
	 * Returns the Data Store Array
	 *
	 * @author Varun Shoor
	 * @return mixed "_dataStore" Array on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetDataStore()
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		}

		return $this->_dataStore;
	}

	/**
	 * Retrieves a Property Value from Data Store
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_propertyName
	 *
	 * @return mixed
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Get($_propertyName)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		}

		return $this->GetProperty($_propertyName);
	}

	/**
	 * Retrieves a Property Value from Data Store
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_propertyName The Property Name
	 *
	 * @return mixed Property Data on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function GetProperty($_propertyName)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		} else if (!isset($this->_dataStore[$_propertyName])) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_INVALIDDATA);
		}

		$_propertyName = mb_strtolower($_propertyName);

		return $this->_dataStore[$_propertyName];
	}

	/**
	 * Update Property
	 *
	 * @author Varun Shoor
	 *
	 * @param string $_propertyName
	 * @param string $_propertyValue
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function SetProperty($_propertyName, $_propertyValue)
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		} else if (!isset($this->_dataStore[$_propertyName])) {
			throw new SWIFT_Exception('Property update failed, "' . $_propertyName . '" not found in datastore.');
		}

		$_propertyName = mb_strtolower($_propertyName);

		$this->_dataStore[$_propertyName] = $_propertyValue;

		$this->UpdatePool($_propertyName, $_propertyValue);

		return true;
	}

	/**
	 * Load the Data
	 *
	 * @author Varun Shoor
	 *
	 * @param object $_SWIFT_DataObject The SWIFT_Data Object
	 *
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If Invalid Data is Provided
	 */
	protected function LoadData($_SWIFT_DataObject)
	{
		$_SWIFT = SWIFT::GetInstance();


		// Is it a ID?
		if ($_SWIFT_DataObject instanceof SWIFT_DataID && $_SWIFT_DataObject->GetIsClassLoaded()) {
			$_query     = "SELECT * FROM " . TABLE_PREFIX . self::GetTableName() . " WHERE " . self::GetPrimaryKeyName() . " = '" . intval($_SWIFT_DataObject->GetDataID()) . "'";
			$_dataStore = $_SWIFT->Database->QueryFetch($_query);
			if (isset($_dataStore[self::GetPrimaryKeyName()]) && !empty($_dataStore[self::GetPrimaryKeyName()])) {
				$this->_dataStore = $_dataStore;

				return true;
			} else {
				return false;
			}
			// Is it a Store?
		} else if ($_SWIFT_DataObject instanceof SWIFT_DataStore && $_SWIFT_DataObject->GetIsClassLoaded()) {
			$this->_dataStore = $_SWIFT_DataObject->GetDataStore();

			if (!isset($this->_dataStore[self::GetPrimaryKeyName()]) || empty($this->_dataStore[self::GetPrimaryKeyName()])) {
				throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_INVALIDDATA);
			}

			return true;
		}

		throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_INVALIDDATA);
	}

	/**
	 * Delete the record
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 * @throws SWIFT_Exception If the Class is not Loaded
	 */
	public function Delete()
	{
		if (!$this->GetIsClassLoaded()) {
			throw new SWIFT_Exception(__CLASS__ . ':  ' . SWIFT_CLASSNOTLOADED);
		} else if (self::GetPrimaryKeyName() === false) {
			return false;
		}

		self::DeleteList(array($this->GetProperty(self::GetPrimaryKeyName())));

		$this->SetIsClassLoaded(false);

		return true;
	}

	/**
	 * Delete a list of records
	 *
	 * @author Varun Shoor
	 *
	 * @param array $_idList
	 *
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function DeleteList($_idList)
	{
		$_SWIFT = SWIFT::GetInstance();

		if (!_is_array($_idList)) {
			return false;
		}

		$_SWIFT->Database->Query("DELETE FROM " . TABLE_PREFIX . self::GetTableName() . " WHERE " . self::GetPrimaryKeyName() . " IN (" . BuildIN($_idList) . ")");

		return true;
	}

	/**
	 * Add an entry into the update pool
	 *
	 * @param string $_key   The key
	 * @param string $_value The value
	 *
	 * @return bool True on success, false otherwise
	 */
	public function UpdatePool($_key, $_value)
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		}

		// Do we have a data store?
		$this->_dataStore[$_key] = $_value;

		$this->_updatePool[$_key] = $_value;

		$this->QueueUpdatePool();

		return true;
	}

	/**
	 * Retrieves the update pool
	 *
	 * @return array The update pool
	 */
	public function GetUpdatePool()
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		}

		return $this->_updatePool;
	}

	/**
	 * Clears the Update Pool
	 *
	 * @return bool True on success, false otherwise
	 */
	public function ClearUpdatePool()
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		}

		$this->_updatePool = array();

		$_keyName = get_class($this) . '_' . $this->GetInstanceID();

		// Clear shutdown queue if set
		if (isset(self::$_updatePoolQueue[$_keyName])) {
			unset(self::$_updatePoolQueue[$_keyName]);
		}

		return true;
	}

	/**
	 * Queue the processing of the update pool for this object
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	public function QueueUpdatePool()
	{
		if (!$this->GetIsClassLoaded()) {
			return false;
		}

		$_keyName = get_class($this) . '_' . $this->GetInstanceID();

		if (!isset(self::$_updatePoolQueue[$_keyName])) {
			self::$_updatePoolQueue[$_keyName] = $this;
		}

		return true;
	}

	/**
	 * Process the pending update pools before shutdown
	 *
	 * @author Varun Shoor
	 * @return bool "true" on Success, "false" otherwise
	 */
	static public function ProcessShutdownUpdatePool()
	{
		if (!_is_array(self::$_updatePoolQueue)) {
			return false;
		}

		foreach (self::$_updatePoolQueue as $_ModelObject) {
			if ($_ModelObject instanceof SWIFT_Model && $_ModelObject->GetIsClassLoaded() && method_exists($_ModelObject, 'ProcessUpdatePool')) {
				$_ModelObject->ProcessUpdatePool();
			}
		}

		self::$_updatePoolQueue = array();

		return true;
	}
}