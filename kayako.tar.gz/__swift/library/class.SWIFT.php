<?php
                    /**
                    * ###############################################
                    *
                    * SWIFT Framework
                    * _______________________________________________
                    *
                    * @package        SWIFT
                    * @copyright    Copyright (c) 2001-2014, Kayako
                    * @license        http://www.kayako.com/license
                    * @link        http://www.kayako.com
                    *
                    * ###############################################
                    */

class SWIFT_License
{
    const LIC_KEY = 'A376545AD82A8B695A60';
    static private $_licenseContainer = false;
    static private $_allChecksPass = false;
    public function __construct()
    {
        parent::__construct();
        return true;
    }
    public function __destruct()
    {
        parent::__destruct();
        return true;
    }
    static public function Load()
    {
        if (SWIFT_INTERFACE == 'setup' || SWIFT_INTERFACE == 'console' || SWIFT_INTERFACE == 'winapp' || SWIFT_INTERFACE == 'visitor') {
            self::$_allChecksPass = true;
            return true;
        }
 
 
        return true;
    }
   
    static public function CheckExpired()
    {
        if (self::$_allChecksPass == true) {
            return true;
        }
        return true;
    }
    static public function CheckValidDomain()
    {
        $_SWIFT = SWIFT::GetInstance();
        if (self::$_allChecksPass == true) {
            return true;
        }
        $_checkHost  = false;
        $_domainData = parse_url($_SWIFT->Settings->Get('general_producturl'));
        if (strtolower(substr($_domainData['host'], 0, 4)) == 'www.') {
            $_checkHost = trim(strtolower(substr($_domainData['host'], 4)));
        } else {
            $_checkHost = trim(strtolower($_domainData['host']));
        }
        unset($_checkHost);
        unset($_domainData);
        $_httpsExtended = '';
        if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] == TRUE) {
            $_httpsExtended = 's';
        }
        $_selfURL    = sprintf('http%s://%s%s', $_httpsExtended, $_SERVER['HTTP_HOST'], $_SERVER['REQUEST_URI']);
        $_checkHost  = false;
        $_domainData = parse_url($_selfURL);
        if (strtolower(substr($_domainData['host'], 0, 4)) == 'www.') {
            $_checkHost = trim(strtolower(substr($_domainData['host'], 4)));
        } else {
            $_checkHost = trim(strtolower($_domainData['host']));
        }
        return true;
    }
    static public function CheckValidStaff()
    {
        $_SWIFT = SWIFT::GetInstance();
        if (self::$_allChecksPass == true) {
            return true;
        }
        $_activeStaffCount = 0;
        $_staffCache       = $_SWIFT->Cache->Get('staffcache');
        foreach ($_staffCache as $_staffContainer) {
            if ($_staffContainer['isenabled'] == '1') {
                $_activeStaffCount++;
            }
        }
        return true;
    }
    static public function CheckPackage()
    {
        $_SWIFT = SWIFT::GetInstance();
        if (self::$_allChecksPass == true) {
            return true;
        }
    }
}
SWIFT_License::Load();
class SWIFT
{
    static private $_alertContainer = array();
    static private $_infoContainer = array();
    static private $_errorContainer = array();
    static private $_errorFieldContainer = array();
    static private $_themePathContainer = array();
    static private $_objectMapContainer = array();
    static private $_Instance = false;
    static private $_valueContainer = array();
    static private $_objectCache = array();
    static protected $_notificationContainer = array();
    static protected $_isDebug = false;
    static private $_interfaceLoaded = false;
    public $FirePHP = false;
    public $Database = false;
    public $Language = false;
    public $Template;
    public $Registry = false;
    public $Interface = false;
    public $App = false;
    public $Session = false;
    public $Settings = false;
    public $Cache = false;
    public $Router = false;
    public $View = false;
    public $Cookie = false;
    public $Console = false;
    public $System = false;
    public $Controller = false;
    public $UserInterface = false;
    public $Load = false;
    public $Staff = false;
    public $User = false;
    public $Hook = false;
    public $HTMLPurifier = false;
    public $TemplateGroup = false;
    public $Input = false;
    public $Server = false;
    public $Cluster = false;
    public $ServerMaster = false;
    public $JavaScript = false;
    public $JobQueueMessage = false;
    public $DynectSession = false;
    public $Log = false;
    const NOTIFICATION_INFO = 'info';
    const NOTIFICATION_ALERT = 'alert';
    const NOTIFICATION_ERROR = 'error';
    const NOTIFICATION_USERS = 'users';
    const DEFAULT_ERROR_REPORTING = E_ALL;
    private function __construct()
    {
        return true;
    }
    protected function Initialize()
    {
        global $_shutdownQueue;
        $this->SanitizeGlobals();
        $_shutdownQueue = array();
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_CONFIGDIRECTORY . '/config.php');
        $this->FirePHP = new SWIFT_FirePHP();
        self::Set('_startTime', GetMicroTime());
        error_reporting(self::DEFAULT_ERROR_REPORTING);
        set_error_handler(array(
            'SWIFT_Exception',
            'GlobalErrorHandler'
        ));
        set_exception_handler(array(
            'SWIFT_Exception',
            'GlobalExceptionHandler'
        ));
        @ini_set('session.use_trans_sid', false);
        @ini_set('session.bug_compat_42', true);
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Database/class.SWIFT_Database.php');
        SWIFT_Database::DefineDSN();
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Interface/class.SWIFT_Interface.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/MVC/class.SWIFT_Model_Interface.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/MVC/class.SWIFT_Model.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/MVC/class.SWIFT_View.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/MVC/class.SWIFT_Controller.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/MVC/class.SWIFT_Library.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Log/class.SWIFT_Log.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/App/class.SWIFT_App.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Cache/class.SWIFT_CacheStore.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/LanguageEngine/class.SWIFT_LanguageEngine.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/TemplateEngine/class.SWIFT_TemplateEngine.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Date/class.SWIFT_Date.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Loader/class.SWIFT_Loader.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Cookie/class.SWIFT_Cookie.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Router/class.SWIFT_Router.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Data/class.SWIFT_Data.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Data/class.SWIFT_DataID.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Data/class.SWIFT_DataStore.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Hook/class.SWIFT_Hook.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/JavaScript/class.SWIFT_JavaScript.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_MODELSDIRECTORY . '/Registry/class.SWIFT_Registry.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_MODELSDIRECTORY . '/Settings/class.SWIFT_Settings.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_MODELSDIRECTORY . '/Session/class.SWIFT_Session.php');
        require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Input/class.SWIFT_Input.php');
        if (SWIFT_INTERFACE == 'tests') {
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Test/class.SWIFT_TestCase.php');
        }
        $this->Log = new SWIFT_Log();
        if (SWIFT_INTERFACE == 'console') {
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/Console/class.SWIFT_Console.php');
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_LIBRARYDIRECTORY . '/System/class.SWIFT_System.php');
            $this->Console = new SWIFT_Console();
            $this->System  = new SWIFT_System();
        }
        if (defined('ENABLE_FORWARDED_IP') && constant('ENABLE_FORWARDED_IP') == true && isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            self::Set('IP', $_SERVER['HTTP_X_FORWARDED_FOR']);
        } elseif (defined('ENABLE_FORWARDED_IP') && constant('ENABLE_FORWARDED_IP') == true && isset($_SERVER['HTTP_CLIENT_IP'])) {
            self::Set('IP', $_SERVER['HTTP_CLIENT_IP']);
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            self::Set('IP', $_SERVER['REMOTE_ADDR']);
        } else {
            self::Set('IP', '');
        }
        self::Set('InstallationHash', '');
        self::Set('ActionHash', BuildHash());
        self::Set('UniqueID', '');
        self::Set('CoreApps', array(
            APP_TICKETS,
            APP_CORE,
            APP_BASE,
            APP_LIVECHAT,
            APP_KNOWLEDGEBASE,
            APP_TROUBLESHOOTER,
            APP_NEWS,
            APP_REPORTS,
            APP_PARSER,
            APP_ONSITE
        ));
        try {
            SWIFT_Loader::RegisterAutoLoad();
            $this->Cookie   = new SWIFT_Cookie();
            $this->Database = new SWIFT_Database();
            if (!$this->Database->IsConnected()) {
                trigger_error('Unable to connect to Database. Please verify the username, password, grant permissions and the database status.', E_USER_ERROR);
                exit;
            }
            self::ProcessDebugMode();
            register_shutdown_function(array(
                $this,
                'ProcessShutdown'
            ));
            $this->Registry  = new SWIFT_Registry();
            $this->Cache     = new SWIFT_CacheStore();
            $this->Interface = SWIFT_Interface::Load();
            $this->Cache->LoadQueue();
            $this->Settings = new SWIFT_Settings();
            $this->Hook     = new SWIFT_Hook();
            $this->Input    = new SWIFT_Input();
            self::Set('InstallationHash', $this->Settings->GetKey('core', 'installationhash'));
            self::Set('timezone', ($this->Settings->Get('dt_timezonephp')) ? $this->Settings->Get('dt_timezonephp') : 'GMT');
            self::Set('daylightsavings', ($this->Settings->Get('dt_daylightsavings') == 1) ? true : false);
            if (!date_default_timezone_set(SWIFT::Get('timezone'))) {
                date_default_timezone_set('GMT');
            }
            setlocale(LC_ALL, SWIFT_LOCALE);
            if (defined('SWIFTLOCALECTYPE')) {
                setlocale(LC_CTYPE, constant('SWIFTLOCALECTYPE'));
            }
            $this->Interface->LoadSettings();
            $this->LoadUserInterfaceFiles();
            SWIFT_Router::ParseTemplateGroup();
            $this->Template = SWIFT_TemplateEngine::LoadEngine();
            $this->Language = SWIFT_LanguageEngine::LoadEngine();
            $this->Template->LoadVariables();
            SWIFT_App::ParseInstalledApps();
            SWIFT_App::ParseConfig();
            SWIFT_Loader::LoadCache();
            $this->LoadUserInterfaceObject();
            $this->Router     = SWIFT_Router::Load();
            $this->JavaScript = new SWIFT_JavaScript();
        }
        catch (Exception $_ExceptionObject) {
            SWIFT_Exception::GlobalExceptionHandler($_ExceptionObject);
            trigger_error($_ExceptionObject->getTraceAsString() . SWIFT_CRLF . $_ExceptionObject->getMessage(), E_USER_ERROR);
            exit;
        }
        SWIFT_License::CheckExpired();
        SWIFT_License::CheckValidStaff();
        SWIFT_License::CheckPackage();
        if (SWIFT_INTERFACE != 'tests') {
            $_interfaceType = $this->Interface->GetInterface();
            if ($_interfaceType == SWIFT_Interface::INTERFACE_ADMIN || $_interfaceType == SWIFT_Interface::INTERFACE_STAFF || $_interfaceType == SWIFT_Interface::INTERFACE_WINAPP || $_interfaceType == SWIFT_Interface::INTERFACE_SYNCWORKS || $_interfaceType == SWIFT_Interface::INTERFACE_RSS || $_interfaceType == SWIFT_Interface::INTERFACE_INTRANET || $_interfaceType == SWIFT_Interface::INTERFACE_PDA || $_interfaceType == SWIFT_Interface::INTERFACE_INSTAALERT || $_interfaceType == SWIFT_Interface::INTERFACE_MOBILE || $_interfaceType == SWIFT_Interface::INTERFACE_API || $_interfaceType == SWIFT_Interface::INTERFACE_STAFFAPI) {
                $this->Language->Load('staffactivitylog');
            }
        }
        $this->App = $this->Router->GetApp();
        $this->App->Initialize();
        $this->Cache->LoadQueue();
        $this->App->ExecuteController($this->Router);
        if (SWIFT_INTERFACE != 'tests') {
            self::RunSystemChecks();
        }
        SWIFT_Loader::RebuildCache();
        SWIFT_License::CheckValidDomain();
        self::ProcessAllShutdownFunctions();
        $_queueCount = $this->Settings->GetKey('mail', 'queuecount');
        if ($_queueCount) {
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_MODELSDIRECTORY . '/Mail/class.SWIFT_MailQueueManager.php');
            $_SWIFT_MailQueueManagerObject = new SWIFT_MailQueueManager();
            $_SWIFT_MailQueueManagerObject->ProcessMailQueue();
        }
        self::Set('_endTime', GetMicroTime());
        $this->FirePHP->Info('Execution Time: ' . number_format(self::Get('_endTime') - self::Get('_startTime'), 5));
        return true;
    }
    static public function ProcessAllShutdownFunctions()
    {
        self::ProcessShutdownQueue(-1);
        SWIFT_Model::ProcessShutdownUpdatePool();
        self::ProcessShutdownQueue();
        return true;
    }
    protected function LoadUserInterfaceFiles()
    {
        if (!file_exists('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_COREAPPSDIRECTORY . '/base/')) {
            return false;
        }
        if ($this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_CLIENT || $this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_VISITOR || $this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_RSS) {
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_COREAPPSDIRECTORY . '/base/' . SWIFT_LIBRARYDIRECTORY . '/UserInterface/class.SWIFT_UserInterface.php');
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_COREAPPSDIRECTORY . '/base/' . SWIFT_LIBRARYDIRECTORY . '/UserInterface/class.SWIFT_UserInterfaceClient.php');
        } else {
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_COREAPPSDIRECTORY . '/base/' . SWIFT_LIBRARYDIRECTORY . '/UserInterface/class.SWIFT_UserInterface.php');
            require_once('./' . SWIFT_BASEDIRECTORY . '/' . SWIFT_COREAPPSDIRECTORY . '/base/' . SWIFT_LIBRARYDIRECTORY . '/UserInterface/class.SWIFT_UserInterfaceControlPanel.php');
        }
        self::$_interfaceLoaded = true;
        return true;
    }
    protected function LoadUserInterfaceObject()
    {
        if (self::$_interfaceLoaded === false) {
            return false;
        }
        if ($this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_CLIENT || $this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_VISITOR || $this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_RSS) {
            $this->UserInterface = new SWIFT_UserInterfaceClient();
        } else if ($this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_STAFF || $this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_INTRANET || $this->Interface->GetInterface() == SWIFT_Interface::INTERFACE_ADMIN) {
            $this->UserInterface = new SWIFT_UserInterfaceControlPanel();
        }
        return true;
    }
    protected function SanitizeGlobals()
    {
        if (isset($_REQUEST['GLOBALS']) || isset($_FILES['GLOBALS'])) {
            die('Globals overwrite attempt detected! Terminating.');
        }
        $_reserved = array(
            '_reserved',
            'GLOBALS',
            '_GET',
            '_POST',
            '_COOKIE',
            '_SERVER',
            '_ENV',
            '_REQUEST',
            '_FILES',
            'argv'
        );
        if (is_array($GLOBALS)) {
            reset($GLOBALS);
            while (list($_key, $_val) = each($GLOBALS)) {
                if (!in_array($_key, $_reserved) && ($_key != '_key' && $_key != '_val')) {
                    unset($GLOBALS[$_key]);
                }
            }
        }
        return true;
    }
    static public function GetInstance()
    {
        if (!self::$_Instance) {
            self::$_Instance = new SWIFT();
            self::$_Instance->Initialize();
        }
        return self::$_Instance;
    }
    static public function Get($_key)
    {
        if (!isset(self::$_valueContainer[$_key])) {
            return false;
        }
        return self::$_valueContainer[$_key];
    }
    static public function Set($_key, $_value = '')
    {
        self::$_valueContainer[$_key] = $_value;
        return true;
    }
    static public function SetReference($_key, &$_value)
    {
        if (empty($_key)) {
            return false;
        }
        if (empty($_value)) {
            unset(self::$_valueContainer[$_key]);
            return true;
        }
        self::$_valueContainer[$_key] =& $_value;
        return true;
    }
    static public function GetInfoContainer()
    {
        return self::$_infoContainer;
    }
    static public function GetAlertContainer()
    {
        return self::$_alertContainer;
    }
    static public function GetErrorContainer()
    {
        return self::$_errorContainer;
    }
    static public function GetErrorFieldContainer()
    {
        return self::$_errorFieldContainer;
    }
    static public function ResetAllContainers()
    {
        self::$_infoContainer  = array();
        self::$_alertContainer = array();
        self::$_errorContainer = array();
        return true;
    }
    static public function Info($_title, $_message)
    {
        if (empty($_title) || empty($_message)) {
            return false;
        }
        self::$_infoContainer[] = array(
            'title' => self::$_Instance->Input->SanitizeForXSS($_title),
            'message' => self::$_Instance->Input->SanitizeForXSS($_message)
        );
        return true;
    }
    static public function Alert($_title, $_message)
    {
        if (empty($_title) || empty($_message)) {
            return false;
        }
        self::$_alertContainer[] = array(
            'title' => self::$_Instance->Input->SanitizeForXSS($_title),
            'message' => self::$_Instance->Input->SanitizeForXSS($_message)
        );
        return true;
    }
    static public function Error($_title, $_message)
    {
        if (empty($_title) || empty($_message)) {
            return false;
        }
        self::$_errorContainer[] = array(
            'title' => self::$_Instance->Input->SanitizeForXSS($_title),
            'message' => self::$_Instance->Input->SanitizeForXSS($_message)
        );
        return true;
    }
    static public function ErrorField($_fieldName)
    {
        if (empty($_fieldName)) {
            return false;
        }
        if (count(func_get_args()) > 1) {
            foreach (func_get_args() as $_key => $_val) {
                if (!in_array($_val, self::$_errorFieldContainer)) {
                    self::$_errorFieldContainer[] = $_val;
                }
            }
        } else {
            self::$_errorFieldContainer[] = $_fieldName;
        }
        return true;
    }
    public function SetClass($_className, SWIFT_Base $_SWIFTObject)
    {
        $this->$_className = $_SWIFTObject;
        self::AddToObjectMap($_SWIFTObject);
        foreach (self::$_objectMapContainer as $_key => $_SWIFT_BaseObject) {
            if ($_SWIFT_BaseObject instanceof SWIFT_Base && $_SWIFT_BaseObject->GetIsClassLoaded()) {
                $_SWIFT_BaseObject->UpdateObject($_className, $_SWIFTObject);
            }
        }
        return true;
    }
    static public function AddToObjectMap(SWIFT_Base $_SWIFT_BaseObject)
    {
        $_SWIFT = SWIFT::GetInstance();
        if ($_SWIFT_BaseObject instanceof SWIFT_Base && $_SWIFT_BaseObject->GetIsClassLoaded()) {
            self::$_objectMapContainer[] = $_SWIFT_BaseObject;
        }
        return true;
    }
    static public function GetObjectMap()
    {
        return self::$_objectMapContainer;
    }
    static public function Shutdown($_SWIFT_Object, $_callBackFunction, $_queueBatch = 1, $_replaceIndex = false)
    {
        global $_shutdownQueue;
        $_SWIFT = SWIFT::GetInstance();
        if ((is_object($_SWIFT_Object) && (!$_SWIFT_Object instanceof SWIFT_Base || !$_SWIFT_Object->GetIsClassLoaded())) || (is_string($_SWIFT_Object) && (empty($_SWIFT_Object) || !class_exists($_SWIFT_Object, false)))) {
            throw new SWIFT_Exception(SWIFT_INVALIDDATA);
        }
        $_functionArguments      = func_get_args();
        $_finalFunctionArguments = array();
        foreach ($_functionArguments as $_key => $_val) {
            if ($_key > 3) {
                $_finalFunctionArguments[] = $_val;
            }
        }
        $_index = 0;
        if (isset($_shutdownQueue[$_queueBatch])) {
            $_index = count($_shutdownQueue[$_queueBatch]);
        } else {
            $_shutdownQueue[$_queueBatch] = array();
        }
        if ($_replaceIndex !== false) {
            $_index = $_replaceIndex;
        }
        $_shutdownQueue[$_queueBatch][$_index] = array(
            $_SWIFT_Object,
            $_callBackFunction,
            $_finalFunctionArguments
        );
        return $_index;
    }
    static public function PrintShutdownQueue($_batchNumber = false)
    {
        global $_shutdownQueue;
        $_SWIFT = SWIFT::GetInstance();
        for ($index = -1; $index <= 10; $index++) {
            $_batchNumber = $index;
            if (!isset($_shutdownQueue[$_batchNumber]) || !_is_array($_shutdownQueue[$_batchNumber])) {
                continue;
            }
            $_queueContainerList = $_shutdownQueue[$_batchNumber];
            foreach ($_queueContainerList as $_queueContainer) {
                if (is_string($_queueContainer[0])) {
                    echo 'S:' . $_queueContainer[0];
                } else {
                    echo 'C:' . get_class($_queueContainer[0]) . '(' . $_queueContainer[0]->GetInstanceID() . ')';
                }
                echo '::' . $_queueContainer[1] . '<br />';
                echo '<br />' . SWIFT_CRLF;
            }
        }
        return true;
    }
    static public function ProcessShutdownQueue($_batchNumber = false)
    {
        global $_shutdownQueue;
        $_SWIFT = SWIFT::GetInstance();
        if ($_batchNumber !== false) {
            if (isset($_shutdownQueue[$_batchNumber]) && _is_array($_shutdownQueue[$_batchNumber])) {
                foreach ($_shutdownQueue[$_batchNumber] as $_queueContainer) {
                    $_result = call_user_func_array(array(
                        $_queueContainer[0],
                        $_queueContainer[1]
                    ), $_queueContainer[2]);
                }
            }
            $_shutdownQueue[$_batchNumber] = array();
            return true;
        }
        for ($index = -1; $index <= 10; $index++) {
            $_batchNumber = $index;
            if (!isset($_shutdownQueue[$_batchNumber]) || !_is_array($_shutdownQueue[$_batchNumber])) {
                $_shutdownQueue[$_batchNumber] = array();
                continue;
            }
            $_queueContainerList = $_shutdownQueue[$_batchNumber];
            foreach ($_queueContainerList as $_queueContainer) {
                call_user_func_array(array(
                    $_queueContainer[0],
                    $_queueContainer[1]
                ), $_queueContainer[2]);
            }
        }
        $_shutdownQueue = array();
        return true;
    }
    static public function RunSystemChecks()
    {
        $_SWIFT = SWIFT::GetInstance();
        if ((SWIFT_INTERFACE == 'staff' || SWIFT_INTERFACE == 'admin' || SWIFT_INTERFACE == 'intranet') && file_exists('./setup') && is_dir('./setup') && SWIFT::Get('IP') != '127.0.0.1' && !preg_match('/kayako-test.com/', $_SWIFT->Settings->Get('general_producturl'))) {
            echo '<div style="position: absolute; left: 10px; top: 0; right: 10px; border: 1px SOLID darkred; background: #ffefbb; z-index: 999999999;"><font face="verdana, arial, helvetica, serif" size="3" color="red"><b>ERROR:</b> Setup directory has not been deleted. It is recommended that you immediately delete the setup directory to prevent any damage to your database.<br /><br />For more information please contact the kayako support at https://my.kayako.com</font></div>';
        } else if ((SWIFT_INTERFACE == 'staff' || SWIFT_INTERFACE == 'admin' || SWIFT_INTERFACE == 'intranet') && $_SWIFT->Settings->GetKey('core', 'version') != SWIFT_VERSION) {
            echo '<div style="position: absolute; left: 10px; top: 0; right: 10px; border: 1px SOLID darkred; background: #ffefbb; z-index: 999999999;"><font face="verdana, arial, helvetica, serif" size="3" color="red"><b>ERROR:</b> Product file version (' . SWIFT_VERSION . ') does not match with the database version (' . $_SWIFT->Settings->GetKey('core', 'version') . '). Please run the upgrade script to ensure that the product is up to date.<br /><br />For more information please contact the kayako support at https://my.kayako.com</font></div>';
        }
        return true;
    }
    static public function CacheObject(SWIFT_Base $_SWIFT_BaseObject, $_objectIdentifier)
    {
        $_SWIFT     = SWIFT::GetInstance();
        $_className = get_class($_SWIFT_BaseObject);
        if (!isset(self::$_objectCache[$_className])) {
            self::$_objectCache[$_className] = array();
        }
        self::$_objectCache[$_className][$_objectIdentifier] = $_SWIFT_BaseObject;
        return true;
    }
    static public function IsObjectCached(SWIFT_Base $_SWIFT_BaseObject, $_objectIdentifier)
    {
        $_SWIFT     = SWIFT::GetInstance();
        $_className = get_class($_SWIFT_BaseObject);
        if (isset(self::$_objectCache[$_className][$_objectIdentifier])) {
            return true;
        }
        return false;
    }
    static public function GetCachedObject(SWIFT_Base $_SWIFT_BaseObject, $_objectIdentifier)
    {
        $_SWIFT     = SWIFT::GetInstance();
        $_className = get_class($_SWIFT_BaseObject);
        if (isset(self::$_objectCache[$_className][$_objectIdentifier])) {
            return self::$_objectCache[$_className][$_objectIdentifier];
        }
        throw new SWIFT_Exception(SWIFT_INVALIDDATA);
        return false;
    }
    static public function IsValidNotificationType($_notificationType)
    {
        return ($_notificationType == self::NOTIFICATION_INFO || $_notificationType == self::NOTIFICATION_ALERT || $_notificationType == self::NOTIFICATION_ERROR || $_notificationType == self::NOTIFICATION_USERS);
    }
    static public function Notify($_notificationType, $_notificationText)
    {
        if (!self::IsValidNotificationType($_notificationType)) {
            throw new SWIFT_Exception(SWIFT_INVALIDDATA);
        }
        if (!isset(self::$_notificationContainer[$_notificationType])) {
            self::$_notificationContainer[$_notificationType] = array();
        }
        self::$_notificationContainer[$_notificationType][] = $_notificationText;
        return true;
    }
    static public function GetNotificationContainer()
    {
        return self::$_notificationContainer;
    }
    static public function IsCP()
    {
        $_SWIFT         = SWIFT::GetInstance();
        $_interfaceName = $_SWIFT->Interface->GetName();
        if ($_interfaceName == 'staff' || $_interfaceName == 'admin' || $_interfaceName == 'intranet') {
            return true;
        }
        return false;
    }
    static public function IsDebug()
    {
        return self::$_isDebug;
    }
    static public function ProcessDebugMode()
    {
        $_SWIFT = SWIFT::GetInstance();
        if ((defined('SWIFT_DEBUG') && constant('SWIFT_DEBUG') === true) || (SWIFT::Get('IP') == '127.0.0.1') || (SWIFT::Get('IP') == '::1')) {
            self::$_isDebug = true;
        } else {
            self::$_isDebug = false;
        }
        return true;
    }
    public function ProcessShutdown()
    {
        $_errorContainer = error_get_last();
        if ($_errorContainer !== NULL) {
            chdir(SWIFT_BASEPATH);
            $_SWIFT_LogObject = new SWIFT_Log('error');
            $_SWIFT_LogObject->Log($_errorContainer['type'] . ': ' . $_errorContainer['message'] . ' in ' . $_errorContainer['file'] . ':' . $_errorContainer['line']);
        }
        return true;
    }
    static public function SetThemePath($_themePathName, $_templateVariableName, $_themePath)
    {
        SWIFT::Set($_themePathName, $_themePath);
        self::$_themePathContainer[$_themePathName] = array(
            $_templateVariableName,
            $_themePath
        );
        return true;
    }
    static public function GetThemePath()
    {
        return self::$_themePathContainer;
    }
}
?>